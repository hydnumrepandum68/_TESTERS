/*
  OBJECTIF
  Verif sequence classique : open -> get_next_line en boucle -> close.
  "Vider" = lire fichier jusque EOF, GNL doit renvoyer NULL et le stash interne doit etre vide
  Détecter lignes tronquées si BUFFER_SIZE petit, oubli de close, fuites mémoire
 
  USAGE
  ./a.out text.txt
*/

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include "get_next_line.h"

int main(int argc, char **argv)
{
    if (argc != 2)
    {
        printf("Usage: %s <fichier>\n", argv[0]);
        return 1;
    }
    int fd = open(argv[1], O_RDONLY);
    if (fd == -1)
        return (perror("open"), 1);

    char  *line;
    int   i = 1;
    while ((line = get_next_line(fd)) != NULL)
    {
        printf("[%d] %s", i++, line);
        free(line);
    }
    close(fd);
    return 0;
}
