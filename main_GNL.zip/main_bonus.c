/*
  OBJECTIF = 3 FDs en alternance
  verif que plusieurs fds peuvent etre geres en parallele sans tout melanger
  on lit en boucle fd1 -> fd2 -> fd3 jusque EOF partout

  USAGE
  ./a.out file1 file2 file3
*/

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include "get_next_line_bonus.h"

static int safe_open(const char *path)
{
    int fd = open(path, O_RDONLY);
    if (fd < 0)
        perror(path);
    return fd;
}

int main(int argc, char **argv)
{
    const char *p1;
    const char *p2;
    const char *p3;

    if (argc == 4)
    {
        p1 = argv[1];
        p2 = argv[2];
        p3 = argv[3];
    }
    else
    {
        p1 = "1char.txt";
        p2 = "16chars_x10.txt";
        p3 = "text.txt";
    }

    int fd1 = safe_open(p1);
    int fd2 = safe_open(p2);
    int fd3 = safe_open(p3);

    if (fd1 < 0 || fd2 < 0 || fd3 < 0)
    {
        if (fd1 >= 0) close(fd1);
        if (fd2 >= 0) close(fd2);
        if (fd3 >= 0) close(fd3);
        fprintf(stderr, "Usage: %s file1 file2 file3\n", argv[0]);
        return 1;
    }

    int done1 = 0;
    int done2 = 0;
    int done3 = 0;
    int i1 = 1;
    int i2 = 1;
    int i3 = 1;
    char *line;

    while (!(done1 && done2 && done3))
    {
        if (!done1)
        {
            line = get_next_line(fd1);
            if (line) { printf("[fd1:%s][%d] %s", p1, i1, line); free(line); i1 = i1 + 1; }
            else      { done1 = 1; }
        }
        if (!done2)
        {
            line = get_next_line(fd2);
            if (line) { printf("[fd2:%s][%d] %s", p2, i2, line); free(line); i2 = i2 + 1; }
            else      { done2 = 1; }
        }
        if (!done3)
        {
            line = get_next_line(fd3);
            if (line) { printf("[fd3:%s][%d] %s", p3, i3, line); free(line); i3 = i3 + 1; }
            else      { done3 = 1; }
        }
    }

    close(fd1);
    close(fd2);
    close(fd3);
    return 0;
}
