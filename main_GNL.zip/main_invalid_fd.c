/*
  OBJECTIF
  Provoquer erreur de lecture en appelant GNL avec un fd invalide
  Doit détecter erreur et retourner NULL, sans fuite ni segfault ni boucle infinie
 
  USAGE
  ./a.out
*/

#include <stdio.h>
#include <stdlib.h>
#include "get_next_line.h"

int main(void)
{
    char *line = get_next_line(-1);
    if (line)
    {
        printf("BUG: get_next_line(-1) a renvoyé une ligne: %s\n", line);
        free(line);
        return 1;
    }
    printf("OK: get_next_line(-1) renvoie NULL.\n");
    return 0;
}
