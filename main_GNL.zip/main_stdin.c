/*
  OBJECTIF
  Vérif que GNL lit correctement depuis stdin (fd 0)
  Derniere ligne sans \n doit etre envoyee une fois avant de renvoyer NULL
  Detecter que pas de boucle infinie et pas de fuite
 
  USAGE
  ./a.out                  # tape des lignes, termine par Ctrl+D
  ./a.out < text.txt       # lecture via redirection
  printf "A\nB\nC" | ./gnl_stdin
*/

#include <stdio.h>
#include <stdlib.h>
#include "get_next_line.h"

int main(void)
{
    char  *line;
    int   i = 1;

    while ((line = get_next_line(0)) != NULL)
    {
        printf("[%d] %s", i++, line);
        free(line);
    }
    return 0;
}
